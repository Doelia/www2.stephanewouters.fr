<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<div class="container">

    <div class="menu">
        <a href="index.php">ADMIN</a>
        -
        <a href="../">RETOUR AU SITE</a>
    </div>
