<?php

// Entrez ici les informations de connexions a la base de donnée
// Laissez les double quotes (guillemets) autour des valeurs ****/
$DATABASE_HOST = "127.0.0.1";
$DATABASE_PORT = "3306";
$DATABASE_USERNAME = "root";
$DATABASE_PASSWORD = "motdepasse";
$DATABASE_NAME = "nomdelabdd";

require('init_db.php');
