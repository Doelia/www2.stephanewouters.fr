<!DOCTYPE html>
<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Selectionnez une image à uploader
    <input type="file" name="image" id="image">
    <input type="submit" value="Envoyer" name="submit">
</form>

</body>
</html>
