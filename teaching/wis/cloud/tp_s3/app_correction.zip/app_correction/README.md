Ce projet n'est pas complet pour qu'il fonctionne.
Il faut :
- Installer les dépendances composer avec "composer install"
- Fixer les valeurs des clés google key (suivre le TP)
