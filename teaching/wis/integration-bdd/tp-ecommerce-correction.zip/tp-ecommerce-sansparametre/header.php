<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <div class="menu">
        <a href="products.php">PRODUITS</a> |
        <a href="customers.php">CLIENTS</a>
    </div>
