<?php

echo file_get_contents('contenu.txt');
